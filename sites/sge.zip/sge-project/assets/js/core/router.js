// Router - Role-based routing after login

class Router {
  constructor() {
    this.routes = {
      professor: '/professor/index.html',
      pai: '/pai/index.html',
      diretor: '/diretor/index.html',
      admin: '/admin/index.html'
    };
  }

  redirectByRole(role) {
    const route = this.routes[role];
    if (route) {
      window.location.href = route;
    } else {
      window.location.href = '/auth/login.html';
    }
  }

  isAuthenticated() {
    return !!sessionStorage.getItem('user');
  }

  getCurrentUser() {
    const user = sessionStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}

const router = new Router();
