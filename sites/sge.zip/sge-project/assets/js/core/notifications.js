// Notifications System

class NotificationManager {
  constructor() {
    this.toasts = [];
    this.container = null;
    this.initContainer();
  }

  initContainer() {
    this.container = document.getElementById('toastContainer');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toastContainer';
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  }

  show(message, type = 'info', duration = 4000) {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
      success: 'ti-check',
      danger: 'ti-x',
      warning: 'ti-alert-triangle',
      info: 'ti-info-circle'
    };

    toast.innerHTML = `
      <i class="ti ${icons[type]}"></i>
      <span>${message}</span>
      <button class="toast-close" onclick="this.parentElement.remove()">
        <i class="ti ti-x"></i>
      </button>
    `;

    this.container.appendChild(toast);
    
    if (duration) {
      setTimeout(() => toast.remove(), duration);
    }

    return toast;
  }

  success(message) { return this.show(message, 'success'); }
  error(message) { return this.show(message, 'danger'); }
  warning(message) { return this.show(message, 'warning'); }
  info(message) { return this.show(message, 'info'); }
}

const notifications = new NotificationManager();
