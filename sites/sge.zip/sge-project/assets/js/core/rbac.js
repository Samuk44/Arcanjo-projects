// Role-Based Access Control

class RBAC {
  constructor() {
    this.permissions = {
      professor: ['view_dashboard', 'create_chamada', 'send_bilhete', 'view_notas'],
      pai: ['view_notifications', 'view_grades', 'view_attendance'],
      diretor: ['approve_users', 'manage_turmas', 'view_reports'],
      admin: ['manage_system', 'view_logs', 'manage_users']
    };
  }

  hasPermission(role, permission) {
    return this.permissions[role]?.includes(permission) || false;
  }

  checkAccess(requiredRole) {
    const user = router.getCurrentUser();
    if (!user || user.role !== requiredRole) {
      window.location.href = '/errors/sem-permissao.html';
      return false;
    }
    return true;
  }

  canAccess(role, permission) {
    return this.hasPermission(role, permission);
  }
}

const rbac = new RBAC();
