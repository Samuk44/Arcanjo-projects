// Session Management

class Session {
  constructor() {
    this.user = null;
    this.loadUser();
  }

  loadUser() {
    const userData = sessionStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
    }
  }

  setUser(userData) {
    this.user = userData;
    sessionStorage.setItem('user', JSON.stringify(userData));
  }

  getUser() {
    return this.user;
  }

  clearSession() {
    this.user = null;
    sessionStorage.removeItem('user');
  }

  isLoggedIn() {
    return !!this.user;
  }

  getUserRole() {
    return this.user?.role;
  }

  getUserId() {
    return this.user?.id;
  }
}

const session = new Session();
