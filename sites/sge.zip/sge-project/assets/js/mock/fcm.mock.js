// Mock FCM

class MockFCM {
  async requestPermission() {
    return new Promise((resolve) => {
      setTimeout(() => resolve(true), 300);
    });
  }

  async getToken() {
    return new Promise((resolve) => {
      setTimeout(() => resolve('mock-fcm-token'), 300);
    });
  }

  onMessage(callback) {
    console.log('Mock FCM: Listening for messages');
  }
}

const mockFCM = new MockFCM();
