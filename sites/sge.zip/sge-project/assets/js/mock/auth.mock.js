// Mock Firebase Auth

class MockFirebaseAuth {
  async login(email, password) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = mockData.users.find(u => u.email === email);
        if (user) {
          resolve({ ...user, token: 'mock-token' });
        } else {
          resolve(null);
        }
      }, 500);
    });
  }

  async logout() {
    return new Promise((resolve) => {
      setTimeout(() => resolve(true), 300);
    });
  }
}

const mockAuth = new MockFirebaseAuth();
