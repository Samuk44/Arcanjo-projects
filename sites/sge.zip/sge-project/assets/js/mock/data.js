// Mock Data for Development

const mockData = {
  users: [
    {
      id: 'prof1',
      name: 'Carlos Menezes',
      email: 'carlos@escola.edu.br',
      role: 'professor',
      avatar: 'CM',
      status: 'approved'
    },
    {
      id: 'pai1',
      name: 'João Silva',
      email: 'joao@email.com',
      role: 'pai',
      avatar: 'JS',
      filhos: ['aluno1', 'aluno2']
    },
    {
      id: 'dir1',
      name: 'Maria Diretor',
      email: 'maria@escola.edu.br',
      role: 'diretor',
      avatar: 'MD'
    }
  ],

  turmas: [
    {
      id: 'turma1',
      nome: '7º Ano A',
      ano: 7,
      letra: 'A',
      turno: 'manhã',
      alunosIds: ['aluno1', 'aluno2', 'aluno3']
    },
    {
      id: 'turma2',
      nome: '7º Ano B',
      ano: 7,
      letra: 'B',
      turno: 'tarde',
      alunosIds: ['aluno4', 'aluno5']
    }
  ],

  alunos: [
    {
      id: 'aluno1',
      nome: 'João Santos',
      matricula: 'ALU001',
      turmaId: 'turma1',
      responsavelId: 'pai1',
      frequencia: 0.92,
      media: 8.5
    },
    {
      id: 'aluno2',
      nome: 'Maria Silva',
      matricula: 'ALU002',
      turmaId: 'turma1',
      responsavelId: 'pai1',
      frequencia: 0.88,
      media: 7.8
    }
  ],

  chamadas: [
    {
      id: 'chamada1',
      turmaId: 'turma1',
      data: new Date().toISOString(),
      registros: {
        'aluno1': 'P',
        'aluno2': 'P',
        'aluno3': 'F'
      }
    }
  ],

  notificacoes: [
    {
      id: 'notif1',
      tipo: 'falta',
      titulo: 'Falta Registrada',
      mensagem: 'João Santos foi marcado com falta',
      alunoId: 'aluno1',
      data: new Date().toISOString(),
      lida: false
    }
  ]
};
