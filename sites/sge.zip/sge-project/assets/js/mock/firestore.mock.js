// Mock Firestore

class MockFirestore {
  async getDocument(collection, docId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const data = mockData[collection]?.find(d => d.id === docId);
        resolve(data || null);
      }, 300);
    });
  }

  async getCollection(collection) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockData[collection] || []);
      }, 300);
    });
  }

  async createDocument(collection, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const id = `${collection}-${Date.now()}`;
        const doc = { id, ...data };
        if (!mockData[collection]) mockData[collection] = [];
        mockData[collection].push(doc);
        resolve(doc);
      }, 300);
    });
  }
}

const mockFirestore = new MockFirestore();
