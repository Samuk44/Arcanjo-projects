import { db } from "../../firebase/firebase.config.js";
import { ref, get, query, orderByChild, equalTo } from "firebase/database";

const USERS = "users";

export async function getUsersBySchool(schoolId) {
  if (!schoolId) return [];
  const snap = await get(
    query(ref(db, USERS), orderByChild("schoolId"), equalTo(schoolId)),
  );
  if (!snap.exists()) return [];
  return Object.entries(snap.val()).map(([uid, data]) => ({ uid, ...data }));
}

export async function getUsersByRole(schoolId, role) {
  const all = await getUsersBySchool(schoolId);
  return all.filter((u) => u.role === role);
}

export async function getSchoolUsers(schoolId) {
  return getUsersBySchool(schoolId);
}

export async function getSchoolTeachers(schoolId) {
  return getUsersByRole(schoolId, "teacher");
}

export async function getSchoolGuardians(schoolId) {
  return getUsersByRole(schoolId, "guardian");
}
