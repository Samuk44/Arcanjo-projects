import { bootstrap } from "./bootstrap.js";
import { initNavbar } from "../assets/js/home/navbar.js";
import { initFaq } from "../assets/js/home/faq.js";
import { initPricing } from "../assets/js/home/pricing.js";
import { initAnalytics } from "../assets/js/home/analytics.js";
import { initAnimations } from "../assets/js/home/animations.js";
import { initCta } from "../assets/js/home/cta.js";

bootstrap(() => {
  initNavbar();
  initFaq();
  initPricing();
  initAnalytics();
  initAnimations();
  initCta();
});
