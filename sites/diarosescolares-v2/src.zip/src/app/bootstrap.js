import { Logger } from "../assets/js/shared/logger.js";

export function bootstrap(initFn) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      Logger.page.loaded();
      initFn();
    });
  } else {
    Logger.page.loaded();
    initFn();
  }
}
