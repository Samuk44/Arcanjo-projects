import { authController } from "../../../auth/auth.controller.js";
import { bindLogoutButton } from "../../../assets/js/auth/logout.js";
import {
  loadDirectorDashboardData,
  renewDirectorInvite,
} from "./dashboard.service.js";
import {
  renderLoading,
  renderError,
  renderDashboard,
} from "./dashboard.view.js";

const appRoot = document.getElementById("director-dashboard-app");

const state = {
  data: null,
  filters: {
    query: "",
    classId: "all",
    teacherId: "all",
    status: "all",
  },
  ui: {
    activeInviteRole: "teacher",
    loadingInviteRole: "",
    notice: "",
    detailPanel: null,
  },
};

function containsText(text, query) {
  return String(text || "")
    .toLocaleLowerCase("pt-BR")
    .includes(query);
}

function classMatchesTeacher(classItem, teacherId) {
  if (teacherId === "all") return true;
  return classItem.teacherIds.includes(teacherId);
}

function guardianMatchesTeacher(guardianItem, teacherId, classes) {
  if (teacherId === "all") return true;

  return guardianItem.children.some((child) => {
    const klass = classes.find((item) => item.id === child.classId);
    return klass ? klass.teacherIds.includes(teacherId) : false;
  });
}

function applyFilters() {
  const query = state.filters.query.trim().toLocaleLowerCase("pt-BR");
  const allClasses = state.data.lists.classes;

  const classes = state.data.lists.classes.filter((klass) => {
    const matchesQuery =
      !query ||
      containsText(klass.name, query) ||
      containsText(klass.grade, query) ||
      containsText(klass.shift, query) ||
      containsText(klass.teacherLabel, query);
    const matchesClass =
      state.filters.classId === "all" || klass.id === state.filters.classId;
    const matchesTeacher = classMatchesTeacher(klass, state.filters.teacherId);
    const matchesStatus =
      state.filters.status === "all" || klass.status === state.filters.status;
    return matchesQuery && matchesClass && matchesTeacher && matchesStatus;
  });

  const teachers = state.data.lists.teachers.filter((teacher) => {
    const assignedClassIds = teacher.classesAssigned.map((klass) => klass.id);
    const matchesQuery =
      !query ||
      containsText(teacher.name, query) ||
      containsText(teacher.email, query) ||
      teacher.classesAssigned.some((klass) => containsText(klass.name, query));
    const matchesClass =
      state.filters.classId === "all" ||
      assignedClassIds.includes(state.filters.classId);
    const matchesTeacher =
      state.filters.teacherId === "all" ||
      teacher.id === state.filters.teacherId;
    const matchesStatus =
      state.filters.status === "all" || teacher.status === state.filters.status;
    return matchesQuery && matchesClass && matchesTeacher && matchesStatus;
  });

  const guardians = state.data.lists.guardians.filter((guardian) => {
    const childClassIds = guardian.children
      .map((child) => child.classId)
      .filter(Boolean);
    const matchesQuery =
      !query ||
      containsText(guardian.name, query) ||
      containsText(guardian.email, query) ||
      guardian.children.some((child) => containsText(child.name, query));
    const matchesClass =
      state.filters.classId === "all" ||
      childClassIds.includes(state.filters.classId);
    const matchesTeacher = guardianMatchesTeacher(
      guardian,
      state.filters.teacherId,
      allClasses,
    );
    const matchesStatus =
      state.filters.status === "all" ||
      guardian.status === state.filters.status;
    return matchesQuery && matchesClass && matchesTeacher && matchesStatus;
  });

  return { classes, teachers, guardians };
}

function buildDetailPanel() {
  const detail = state.ui.detailPanel;
  if (!detail) return null;

  if (detail.type === "profile") {
    return {
      kicker: "Perfil",
      title: state.data.director.name,
      description: state.data.school.name,
      items: [
        { label: "Escola", value: state.data.school.name },
        { label: "Código da escola", value: state.data.school.id },
        { label: "E-mail", value: state.data.director.email },
        {
          label: "Localização",
          value:
            [state.data.school.city, state.data.school.state]
              .filter(Boolean)
              .join(" · ") || "—",
        },
      ],
    };
  }

  if (detail.type === "class") {
    const klass = state.data.lists.classes.find(
      (item) => item.id === detail.id,
    );
    if (!klass) return null;

    return {
      kicker: "Turma",
      title: klass.name,
      description: `${klass.grade} · ${klass.shift}`,
      items: [
        { label: "Professor", value: klass.teacherLabel },
        { label: "Quantidade de alunos", value: String(klass.studentsCount) },
        { label: "Status", value: klass.statusLabel },
        {
          label: "Alunos",
          value: klass.students.length
            ? klass.students.map((student) => student.name).join(", ")
            : "Nenhum aluno na turma",
        },
      ],
    };
  }

  if (detail.type === "guardian") {
    const guardian = state.data.lists.guardians.find(
      (item) => item.id === detail.id,
    );
    if (!guardian) return null;

    return {
      kicker: "Responsável",
      title: guardian.name,
      description: guardian.email,
      items: [
        { label: "Status", value: guardian.statusLabel },
        { label: "Filhos vinculados", value: String(guardian.childrenCount) },
        {
          label: "Alunos",
          value: guardian.children.length
            ? guardian.children
                .map((child) => `${child.name} (${child.className})`)
                .join(", ")
            : "Nenhum filho vinculado",
        },
      ],
    };
  }

  return null;
}

function rerender() {
  renderDashboard(appRoot, state.data, {
    filters: state.filters,
    filteredLists: applyFilters(),
    detailPanel: buildDetailPanel(),
    ui: state.ui,
  });

  bindLogoutButton(document.getElementById("logout-btn"));
  bindEvents();
}

function navigateTo(path) {
  window.location.href = path;
}

async function handleRenewInvite(role) {
  state.ui.loadingInviteRole = role;
  state.ui.notice = "";
  rerender();

  try {
    state.data = await renewDirectorInvite(role);
    state.ui.activeInviteRole = role;
    state.ui.notice = `Código de ${role === "teacher" ? "professor" : "responsável"} renovado com sucesso.`;
  } catch (error) {
    state.ui.notice = error.message || "Não foi possível renovar o código.";
  } finally {
    state.ui.loadingInviteRole = "";
    rerender();
  }
}

function bindEvents() {
  const searchInput = document.getElementById("director-search");
  const classFilter = document.getElementById("director-class-filter");
  const teacherFilter = document.getElementById("director-teacher-filter");
  const statusFilter = document.getElementById("director-status-filter");

  if (searchInput) {
    searchInput.addEventListener("input", (event) => {
      state.filters.query = event.target.value || "";
      rerender();
    });
  }

  if (classFilter) {
    classFilter.addEventListener("change", (event) => {
      state.filters.classId = event.target.value || "all";
      rerender();
    });
  }

  if (teacherFilter) {
    teacherFilter.addEventListener("change", (event) => {
      state.filters.teacherId = event.target.value || "all";
      rerender();
    });
  }

  if (statusFilter) {
    statusFilter.addEventListener("change", (event) => {
      state.filters.status = event.target.value || "all";
      rerender();
    });
  }

  appRoot.querySelectorAll("[data-action]").forEach((element) => {
    element.addEventListener("click", async (event) => {
      const action = event.currentTarget.dataset.action;
      const id = event.currentTarget.dataset.id || "";
      const role = event.currentTarget.dataset.role || "";

      if (action === "open-profile") {
        state.ui.detailPanel = { type: "profile" };
        rerender();
        return;
      }

      if (action === "close-detail-panel") {
        state.ui.detailPanel = null;
        rerender();
        return;
      }

      if (action === "open-class-details") {
        state.ui.detailPanel = { type: "class", id };
        rerender();
        return;
      }

      if (action === "open-guardian-details") {
        state.ui.detailPanel = { type: "guardian", id };
        rerender();
        return;
      }

      if (action === "switch-invite-role") {
        state.ui.activeInviteRole = role;
        state.ui.notice = "";
        rerender();
        return;
      }

      if (action === "renew-invite") {
        await handleRenewInvite(role);
        return;
      }

      if (action === "link-teacher-class") {
        navigateTo(
          `teacher-assignments.html?teacherId=${encodeURIComponent(id)}`,
        );
        return;
      }

      if (action === "go-classes") {
        navigateTo("classes.html");
        return;
      }

      if (action === "go-students") {
        navigateTo("students.html");
        return;
      }

      if (action === "open-invite") {
        state.ui.activeInviteRole = "teacher";
        state.ui.notice =
          "Use o seletor do bloco acima para trocar entre professor e responsável.";
        rerender();
        return;
      }

      if (action === "open-invite-teacher") {
        state.ui.activeInviteRole = "teacher";
        state.ui.notice = "Convite de professor pronto para compartilhar.";
        rerender();
        return;
      }

      if (action === "open-invite-guardian") {
        state.ui.activeInviteRole = "guardian";
        state.ui.notice = "Convite de responsável pronto para compartilhar.";
        rerender();
      }
    });
  });
}

async function init() {
  const user = await authController.guardRoute("director");
  if (!user) return;

  renderLoading(appRoot);

  try {
    state.data = await loadDirectorDashboardData();
    state.ui.activeInviteRole = state.data.codeBlock.activeRole;
    rerender();
  } catch (error) {
    renderError(
      appRoot,
      error.message || "Erro ao carregar dados do dashboard.",
    );
  } finally {
    document.body.style.visibility = "visible";
  }
}

init();
