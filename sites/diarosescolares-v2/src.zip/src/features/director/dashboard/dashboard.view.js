function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderSummaryCard(label, value, icon) {
  return `
    <article class="director-summary-card glass-card card-hover">
      <div class="director-summary-icon">${icon}</div>
      <div>
        <p class="director-summary-label">${escapeHtml(label)}</p>
        <strong class="director-summary-value">${escapeHtml(value)}</strong>
      </div>
    </article>
  `;
}

function renderStatusBadge(status, label) {
  return `<span class="status-badge status-${escapeHtml(status)}">${escapeHtml(label)}</span>`;
}

function renderInviteBlock(codeBlock, uiState) {
  const activeRole =
    uiState.activeInviteRole || codeBlock.activeRole || "teacher";
  const invite =
    codeBlock.invites.find((item) => item.role === activeRole) ||
    codeBlock.invites[0];
  const notice = uiState.notice
    ? `<p class="invite-notice">${escapeHtml(uiState.notice)}</p>`
    : "";

  return `
    <section class="director-code-block glass-card">
      <div class="director-section-head">
        <div>
          <span class="director-kicker">Código da escola</span>
          <h2>Convite de ${escapeHtml(invite.label.toLowerCase())}</h2>
        </div>
        <div class="invite-role-switch" role="tablist" aria-label="Tipo de convite">
          ${codeBlock.invites
            .map(
              (item) => `
                <button
                  type="button"
                  class="invite-role-btn ${item.role === activeRole ? "is-active" : ""}"
                  data-action="switch-invite-role"
                  data-role="${escapeHtml(item.role)}"
                >
                  ${escapeHtml(item.label)}
                </button>
              `,
            )
            .join("")}
        </div>
      </div>

      <div class="director-code-grid">
        <div class="director-code-current">
          <span class="director-code-label">Código atual</span>
          <strong class="director-code-value">${escapeHtml(invite.code || "Ainda não gerado")}</strong>
        </div>
        <div class="director-code-meta">
          <div>
            <span class="director-code-label">Tempo restante</span>
            <strong>${escapeHtml(invite.remainingLabel)}</strong>
          </div>
          <div>
            <span class="director-code-label">Status</span>
            ${renderStatusBadge(invite.status, invite.statusLabel)}
          </div>
          <button
            type="button"
            class="primary-button"
            data-action="renew-invite"
            data-role="${escapeHtml(invite.role)}"
            ${uiState.loadingInviteRole === invite.role ? "disabled" : ""}
          >
            ${uiState.loadingInviteRole === invite.role ? "Renovando..." : "Renovar"}
          </button>
        </div>
      </div>
      ${notice}
    </section>
  `;
}

function renderSearchFilters(filters, data) {
  return `
    <section class="director-filters glass-card">
      <div class="director-section-head">
        <div>
          <span class="director-kicker">Busca e filtros</span>
          <h2>Refinar visão do dashboard</h2>
        </div>
      </div>

      <div class="director-filter-grid">
        <label class="director-field">
          <span>Buscar por nome</span>
          <input
            id="director-search"
            type="search"
            value="${escapeHtml(filters.query)}"
            placeholder="Turma, professor, responsável..."
          />
        </label>

        <label class="director-field">
          <span>Turma</span>
          <select id="director-class-filter">
            <option value="all">Todas</option>
            ${data.filters.classes
              .map(
                (item) => `
                  <option value="${escapeHtml(item.id)}" ${filters.classId === item.id ? "selected" : ""}>
                    ${escapeHtml(item.label)}
                  </option>
                `,
              )
              .join("")}
          </select>
        </label>

        <label class="director-field">
          <span>Professor</span>
          <select id="director-teacher-filter">
            <option value="all">Todos</option>
            ${data.filters.teachers
              .map(
                (item) => `
                  <option value="${escapeHtml(item.id)}" ${filters.teacherId === item.id ? "selected" : ""}>
                    ${escapeHtml(item.label)}
                  </option>
                `,
              )
              .join("")}
          </select>
        </label>

        <label class="director-field">
          <span>Status</span>
          <select id="director-status-filter">
            <option value="all">Todos</option>
            ${data.filters.statuses
              .map(
                (item) => `
                  <option value="${escapeHtml(item.id)}" ${filters.status === item.id ? "selected" : ""}>
                    ${escapeHtml(item.label)}
                  </option>
                `,
              )
              .join("")}
          </select>
        </label>
      </div>
    </section>
  `;
}

function renderQuickActions() {
  const actions = [
    { id: "go-classes", label: "Criar turma" },
    { id: "open-invite", label: "Gerar convite" },
    { id: "open-invite-teacher", label: "Cadastrar professor" },
    { id: "open-invite-guardian", label: "Cadastrar responsável" },
    { id: "go-students", label: "Ver alunos" },
  ];

  return `
    <section class="director-quick-actions glass-card">
      <div class="director-section-head">
        <div>
          <span class="director-kicker">Ações rápidas</span>
          <h2>Atalhos do diretor</h2>
        </div>
      </div>
      <div class="director-action-grid">
        ${actions
          .map(
            (action) => `
              <button type="button" class="secondary-button" data-action="${escapeHtml(action.id)}">
                ${escapeHtml(action.label)}
              </button>
            `,
          )
          .join("")}
      </div>
    </section>
  `;
}

function renderAlerts(alerts) {
  if (alerts.length === 0) {
    return `<p class="empty-state">Nenhum alerta importante no momento.</p>`;
  }

  return `
    <ul class="director-alert-list">
      ${alerts
        .map(
          (alert) => `
            <li class="director-alert-item alert-${escapeHtml(alert.level)}">
              <strong>${escapeHtml(alert.title)}</strong>
              <p>${escapeHtml(alert.description)}</p>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderClasses(classes) {
  if (classes.length === 0) {
    return `<p class="empty-state">Nenhuma turma encontrada com os filtros atuais.</p>`;
  }

  return `
    <div class="director-list">
      ${classes
        .map(
          (klass) => `
            <article class="director-row-card">
              <div class="director-row-main">
                <h3>${escapeHtml(klass.name)}</h3>
                <p>${escapeHtml(klass.grade)} · ${escapeHtml(klass.shift)}</p>
              </div>
              <div class="director-row-meta">
                <span>${escapeHtml(String(klass.studentsCount))} alunos</span>
                <span>${escapeHtml(klass.teacherLabel)}</span>
                ${renderStatusBadge(klass.status, klass.statusLabel)}
                <button type="button" class="row-button" data-action="open-class-details" data-id="${escapeHtml(klass.id)}">
                  Detalhes
                </button>
              </div>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderTeachers(teachers) {
  if (teachers.length === 0) {
    return `<p class="empty-state">Nenhum professor encontrado com os filtros atuais.</p>`;
  }

  return `
    <div class="director-list">
      ${teachers
        .map(
          (teacher) => `
            <article class="director-row-card">
              <div class="director-row-main">
                <h3>${escapeHtml(teacher.name)}</h3>
                <p>${escapeHtml(teacher.email)}</p>
              </div>
              <div class="director-row-meta">
                <span>${escapeHtml(String(teacher.classCount))} turmas</span>
                ${renderStatusBadge(teacher.status, teacher.statusLabel)}
                <button type="button" class="row-button" data-action="link-teacher-class" data-id="${escapeHtml(teacher.id)}">
                  Vincular turma
                </button>
              </div>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderGuardians(guardians) {
  if (guardians.length === 0) {
    return `<p class="empty-state">Nenhum responsável encontrado com os filtros atuais.</p>`;
  }

  return `
    <div class="director-list">
      ${guardians
        .map(
          (guardian) => `
            <article class="director-row-card">
              <div class="director-row-main">
                <h3>${escapeHtml(guardian.name)}</h3>
                <p>${escapeHtml(guardian.email)}</p>
              </div>
              <div class="director-row-meta">
                <span>${escapeHtml(String(guardian.childrenCount))} filhos</span>
                ${renderStatusBadge(guardian.status, guardian.statusLabel)}
                <button type="button" class="row-button" data-action="open-guardian-details" data-id="${escapeHtml(guardian.id)}">
                  Detalhes
                </button>
              </div>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderDetailPanel(detailPanel) {
  if (!detailPanel) return "";

  const details = detailPanel.items
    .map(
      (item) => `
        <li>
          <strong>${escapeHtml(item.label)}</strong>
          <span>${escapeHtml(item.value)}</span>
        </li>
      `,
    )
    .join("");

  return `
    <aside class="director-detail-panel glass-card">
      <div class="director-section-head">
        <div>
          <span class="director-kicker">${escapeHtml(detailPanel.kicker)}</span>
          <h2>${escapeHtml(detailPanel.title)}</h2>
        </div>
        <button type="button" class="close-button" data-action="close-detail-panel" aria-label="Fechar painel">
          ×
        </button>
      </div>
      ${detailPanel.description ? `<p class="detail-description">${escapeHtml(detailPanel.description)}</p>` : ""}
      <ul class="detail-list">${details}</ul>
    </aside>
  `;
}

export function renderLoading(container) {
  container.innerHTML = `
    <main class="director-dashboard-shell">
      <section class="director-loading glass-card">
        <span class="director-kicker">Dashboard do diretor</span>
        <h1>Carregando dados da escola...</h1>
      </section>
    </main>
  `;
}

export function renderError(container, message) {
  container.innerHTML = `
    <main class="director-dashboard-shell">
      <section class="director-loading glass-card">
        <span class="director-kicker">Dashboard do diretor</span>
        <h1>Não foi possível abrir o painel.</h1>
        <p>${escapeHtml(message)}</p>
      </section>
    </main>
  `;
}

export function renderDashboard(container, data, viewState) {
  const { filters, filteredLists, detailPanel } = viewState;

  container.innerHTML = `
    <main class="director-dashboard-shell grid-bg">
      <div class="director-bg-glow director-bg-glow-left"></div>
      <div class="director-bg-glow director-bg-glow-right"></div>

      <header class="director-topbar glass-card">
        <div class="director-brand-group">
          <div class="director-brand-mark">DE</div>
          <div>
            <span class="director-kicker">Direção escolar</span>
            <h1 class="gradient-text">${escapeHtml(data.school.name)}</h1>
            <p>Diretor: ${escapeHtml(data.director.name)}</p>
          </div>
        </div>

        <div class="director-topbar-actions">
          <button type="button" class="secondary-button" data-action="open-profile">Perfil</button>
          <button type="button" class="secondary-button danger" id="logout-btn">Sair</button>
        </div>
      </header>

      ${renderInviteBlock(data.codeBlock, viewState.ui)}

      <section class="director-summary-grid">
        ${renderSummaryCard("Professores", String(data.summary.teachers), "👩‍🏫")}
        ${renderSummaryCard("Responsáveis", String(data.summary.guardians), "👨‍👩‍👧")}
        ${renderSummaryCard("Turmas", String(data.summary.classes), "🏫")}
        ${renderSummaryCard("Alunos", String(data.summary.students), "🎓")}
        ${renderSummaryCard("Chamadas de hoje", String(data.summary.attendanceToday), "📋")}
      </section>

      <section class="director-main-grid">
        <div class="director-main-column">
          ${renderSearchFilters(filters, data)}

          <section class="director-panel glass-card">
            <div class="director-section-head">
              <div>
                <span class="director-kicker">Turmas</span>
                <h2>Lista de turmas</h2>
              </div>
              <span class="panel-count">${escapeHtml(String(filteredLists.classes.length))}</span>
            </div>
            ${renderClasses(filteredLists.classes)}
          </section>

          <section class="director-panel glass-card">
            <div class="director-section-head">
              <div>
                <span class="director-kicker">Professores</span>
                <h2>Lista de professores</h2>
              </div>
              <span class="panel-count">${escapeHtml(String(filteredLists.teachers.length))}</span>
            </div>
            ${renderTeachers(filteredLists.teachers)}
          </section>

          <section class="director-panel glass-card">
            <div class="director-section-head">
              <div>
                <span class="director-kicker">Responsáveis</span>
                <h2>Lista de responsáveis</h2>
              </div>
              <span class="panel-count">${escapeHtml(String(filteredLists.guardians.length))}</span>
            </div>
            ${renderGuardians(filteredLists.guardians)}
          </section>
        </div>

        <aside class="director-side-column">
          ${renderQuickActions()}

          <section class="director-panel glass-card">
            <div class="director-section-head">
              <div>
                <span class="director-kicker">Alertas</span>
                <h2>Pontos de atenção</h2>
              </div>
              <span class="panel-count">${escapeHtml(String(data.lists.alerts.length))}</span>
            </div>
            ${renderAlerts(data.lists.alerts)}
          </section>

          ${renderDetailPanel(detailPanel)}
        </aside>
      </section>
    </main>
  `;
}
