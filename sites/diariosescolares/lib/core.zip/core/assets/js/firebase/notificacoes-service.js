const pathBase = "/entregas";
let state = { lista: [], naoLidas: 0, total: 0 };
let dbQuery, dbRef, listener, uid;
const subs = new Set();
function _notify() {
  for (const s of subs)
    try {
      s(state);
    } catch {}
}
export default {
  init: init,
  getState: getState,
  subscribe: subscribe,
  unsubscribe: unsubscribe,
  markAsRead: markAsRead,
  cleanup: cleanup,
};
function init(u) {
  try {
    uid = u?.uid ?? u ?? window.firebase?.auth?.()?.currentUser?.uid;
    if (!uid) return state;
    dbRef = window.firebase?.database?.().ref(`${pathBase}/${uid}`);
    dbQuery = dbRef?.orderByChild("criadoEm");
    listener = dbQuery?.on("value", (snap) => {
      const a = [];
      snap?.forEach?.((c) => {
        const v = c.val();
        a.push(Object.assign({ id: c.key }, v));
      });
      a.sort((x, y) => (y?.criadoEm ?? 0) - (x?.criadoEm ?? 0));
      state.lista = a;
      state.total = a.length;
      state.naoLidas = a.filter((i) => !i?.lido).length;
      _notify();
    });
    window.addEventListener("beforeunload", cleanup);
  } catch (e) {}
  return state;
}
function getState() {
  return state;
}
function subscribe(cb) {
  try {
    if (typeof cb === "function") {
      subs.add(cb);
      cb(state);
      return () => subs.delete(cb);
    }
  } catch {}
  return () => {};
}
function unsubscribe(cb) {
  try {
    subs.delete(cb);
  } catch {}
}
function markAsRead(avisoId) {
  try {
    if (!uid || !avisoId) return;
    const p = `${pathBase}/${uid}/${avisoId}`;
    window.firebase?.database?.().ref(p).update({ lido: true });
    const i = state.lista.findIndex((x) => x.id === avisoId);
    if (i > -1) {
      state.lista[i] = Object.assign({}, state.lista[i], { lido: true });
      state.naoLidas = Math.max(0, state.naoLidas - 1);
      _notify();
    }
  } catch {}
}
function cleanup() {
  try {
    dbQuery && dbQuery.off && dbQuery.off("value", listener);
    window.removeEventListener("beforeunload", cleanup);
    subs.clear();
    dbRef = null;
    dbQuery = null;
    listener = null;
    uid = null;
  } catch {}
}
