/* ==========================================================================
   SGE v2.0 - FIREBASE FCM (Cloud Messaging)
   Notificações Push e Mensageria em Foreground/Background
   ========================================================================== */

import { messaging, db } from "./config.js";
import {
  getToken,
  onMessage,
  deleteToken,
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging.js";
import {
  ref,
  update,
  get,
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js";
import { showToast } from "../core/notifications.js";

// ============================================================
// IMPORTANTE: Substituir pela VAPID Key real do Firebase Console
// Firebase Console > Project Settings > Cloud Messaging > Web Push certificates
// Gere um par de chaves e cole a chave pública aqui
// ============================================================
const VAPID_KEY =
  "BJ_YOUR_VAPID_PUBLIC_KEY_HERE_GENERATE_FROM_FIREBASE_CONSOLE";

/**
 * Registra o Service Worker do Firebase Messaging
 * @returns {Promise<ServiceWorkerRegistration|null>}
 */
async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) {
    console.warn("[FCM] Service Workers não suportados neste navegador.");
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.register(
      "/firebase-messaging-sw.js",
      { scope: "/" }
    );
    console.log("[FCM] Service Worker registrado com sucesso:", registration.scope);
    return registration;
  } catch (error) {
    console.error("[FCM] Erro ao registrar Service Worker:", error);
    return null;
  }
}

/**
 * Solicita permissão e obtém o token FCM
 * @param {string} uid - UID do usuário autenticado
 * @returns {Promise<string|null>} Token FCM ou null
 */
export async function requestNotificationPermission(uid) {
  if (!messaging) {
    console.warn("[FCM] Messaging não disponível neste ambiente.");
    return null;
  }

  if (!("Notification" in window)) {
    console.warn("[FCM] API de Notification não suportada.");
    return null;
  }

  try {
    const permission = await Notification.requestPermission();

    if (permission !== "granted") {
      console.log("[FCM] Permissão de notificação negada pelo usuário.");
      return null;
    }

    const swRegistration = await registerServiceWorker();
    if (!swRegistration) return null;

    const token = await getToken(messaging, {
      vapidKey: VAPID_KEY,
      serviceWorkerRegistration: swRegistration,
    });

    if (token) {
      console.log("[FCM] Token obtido com sucesso.");
      await saveTokenToDatabase(uid, token);
      return token;
    } else {
      console.warn("[FCM] Nenhum token disponível.");
    }
  } catch (error) {
    console.error("[FCM] Erro ao obter token:", error.message);
  }
  return null;
}

/**
 * Salva o token FCM no perfil do usuário no Realtime Database
 * @param {string} uid
 * @param {string} token
 */
async function saveTokenToDatabase(uid, token) {
  try {
    const userRef = ref(db, `usuarios/${uid}`);
    const snapshot = await get(userRef);

    if (snapshot.exists()) {
      await update(userRef, {
        fcmToken: token,
        fcmTokenUpdatedAt: Date.now(),
        notificationsEnabled: true,
      });
      console.log("[FCM] Token salvo no banco de dados para UID:", uid);
    } else {
      console.warn("[FCM] Usuário não encontrado no DB:", uid);
    }
  } catch (error) {
    console.error("[FCM] Erro ao salvar token no DB:", error.message);
  }
}

/**
 * Remove o token FCM (quando usuário desativa notificações ou faz logout)
 * @param {string} uid
 */
export async function removeNotificationToken(uid) {
  if (!messaging) return;

  try {
    await deleteToken(messaging);
    await update(ref(db, `usuarios/${uid}`), {
      fcmToken: null,
      notificationsEnabled: false,
    });
    console.log("[FCM] Token removido com sucesso.");
  } catch (error) {
    console.error("[FCM] Erro ao remover token:", error.message);
  }
}

/**
 * Listener para mensagens recebidas com o app em primeiro plano
 * Exibe toast e vibra o dispositivo
 * @param {Function} [callback] - Callback opcional para processar a notificação
 */
export function setupForegroundListener(callback) {
  if (!messaging) return;

  onMessage(messaging, (payload) => {
    console.log("[FCM] Mensagem recebida em foreground:", payload);

    const title = payload.notification?.title || "Nova Notificação";
    const body = payload.notification?.body || "";

    showToast(`${title}: ${body}`, "info", 8000);

    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100]);
    }

    // Mostrar notificação nativa mesmo em foreground (melhor UX em mobile)
    if (Notification.permission === "granted") {
      new Notification(title, {
        body: body,
        icon: "/assets/img/logo.png",
        tag: payload.data?.tag || "sge-foreground",
      });
    }

    if (callback) callback(payload);
  });
}

/**
 * Inicializa o sistema de notificações completo
 * Deve ser chamado após autenticação do usuário
 * @param {string} uid - UID do usuário
 * @param {Function} [onNotification] - Callback para notificações foreground
 */
export async function initializeNotifications(uid, onNotification) {
  const token = await requestNotificationPermission(uid);

  if (token) {
    setupForegroundListener(onNotification);
    console.log("[FCM] Sistema de notificações inicializado com sucesso.");
  }

  return token;
}

// SGE v2.0 • Firebase FCM • Push Notifications
