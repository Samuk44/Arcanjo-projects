// Firebase Cloud Functions para SGE v2.0
// Versão: 2.1.0 - Push Notifications Completo

const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const { getMessaging } = require("firebase-admin/messaging");
const { getAuth } = require("firebase-admin/auth");
const { setGlobalOptions } = require("firebase-functions/v2");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const {
  onValueCreated,
  onValueUpdated,
} = require("firebase-functions/v2/database");

initializeApp();

setGlobalOptions({ maxInstances: 10, timeoutSeconds: 60 });

// ============================================================
// UTILITÁRIOS
// ============================================================

/**
 * Busca tokens FCM de todos os usuários com determinado role
 */
async function getTokensByRole(role) {
  const snapshot = await getDatabase()
    .ref("/usuarios")
    .orderByChild("role")
    .equalTo(role)
    .once("value");

  const tokens = [];
  if (snapshot.exists()) {
    snapshot.forEach((child) => {
      const userData = child.val();
      if (userData.fcmToken && userData.notificationsEnabled !== false) {
        tokens.push(userData.fcmToken);
      }
    });
  }
  return tokens;
}

/**
 * Busca token FCM de um usuário específico
 */
async function getTokenByUid(uid) {
  const snapshot = await getDatabase()
    .ref(`/usuarios/${uid}/fcmToken`)
    .once("value");
  return snapshot.val() || null;
}

/**
 * Busca tokens FCM dos responsáveis de um aluno
 */
async function getParentTokens(alunoUid) {
  const parentUidsSnapshot = await getDatabase()
    .ref(`/alunos/${alunoUid}/responsaveis`)
    .once("value");

  const parentUids = parentUidsSnapshot.val()
    ? Object.keys(parentUidsSnapshot.val())
    : [];

  const tokens = [];
  for (const parentUid of parentUids) {
    const token = await getTokenByUid(parentUid);
    if (token) tokens.push(token);
  }
  return tokens;
}

/**
 * Envia notificação multicast (para múltiplos tokens)
 */
async function sendMulticastNotification(tokens, title, body, data = {}) {
  if (tokens.length === 0) return { successCount: 0, failureCount: 0 };

  const message = {
    notification: { title, body },
    data: { ...data, click_action: "OPEN_APP" },
    tokens,
  };

  const response = await getMessaging().sendEachForMulticast(message);

  // Remove tokens inválidos do banco
  if (response.failureCount > 0) {
    const invalidTokens = [];
    response.responses.forEach((resp, idx) => {
      if (
        !resp.success &&
        (resp.error?.code === "messaging/invalid-registration-token" ||
          resp.error?.code === "messaging/registration-token-not-registered")
      ) {
        invalidTokens.push(tokens[idx]);
      }
    });

    if (invalidTokens.length > 0) {
      console.log(
        `[FCM] Removendo ${invalidTokens.length} tokens inválidos.`
      );
      // Buscar e limpar tokens inválidos do DB
      const usersSnap = await getDatabase().ref("/usuarios").once("value");
      usersSnap.forEach((child) => {
        if (invalidTokens.includes(child.val().fcmToken)) {
          getDatabase().ref(`/usuarios/${child.key}/fcmToken`).remove();
          getDatabase()
            .ref(`/usuarios/${child.key}/notificationsEnabled`)
            .set(false);
        }
      });
    }
  }

  return response;
}

/**
 * Simulação de e-mail (substituir por SendGrid/Mailgun em produção)
 */
const sendEmail = async (to, subject, body) => {
  console.log(`[EMAIL] Para: ${to} | Assunto: ${subject}`);
  return { success: true };
};

// ============================================================
// CLOUD FUNCTIONS - TRIGGERS AUTOMÁTICOS
// ============================================================

/**
 * Novo cadastro de professor pendente → Notifica diretores
 */
exports.onProfessorCreated = onValueCreated(
  "/cadastrosPendentes/{uid}",
  async (event) => {
    const professorData = event.data.val();
    const uid = event.params.uid;

    if (!professorData) return null;

    try {
      console.log(
        `[onProfessorCreated] Novo cadastro: ${professorData.nome} (${uid})`
      );

      // Busca tokens de TODOS os diretores
      const directorTokens = await getTokensByRole("diretor");

      if (directorTokens.length > 0) {
        const response = await sendMulticastNotification(
          directorTokens,
          "Novo Cadastro de Professor",
          `${professorData.nome} aguarda aprovação.`,
          { type: "cadastro_pendente", uid, url: "/diretor/aprovar-cadastros.html" }
        );
        console.log(
          `[onProfessorCreated] Notificou ${response.successCount} diretores.`
        );
      }

      await getDatabase().ref(`/logs/cadastros/${uid}`).set({
        timestamp: Date.now(),
        action: "cadastro_pendente",
        professorUid: uid,
        professorNome: professorData.nome,
      });
    } catch (error) {
      console.error(`[onProfessorCreated] Erro:`, error);
      throw error;
    }
    return null;
  }
);

/**
 * Professor aprovado → Envia e-mail + notificação push
 */
exports.onApproval = onValueUpdated("/usuarios/{uid}", async (event) => {
  const beforeData = event.data.before.val();
  const afterData = event.data.after.val();
  const uid = event.params.uid;

  if (
    beforeData.status !== "ativo" &&
    afterData.status === "ativo" &&
    afterData.role === "professor"
  ) {
    try {
      console.log(`[onApproval] Professor ${afterData.nome} aprovado.`);

      // Set custom claims
      try {
        await getAuth().setCustomUserClaims(uid, { role: afterData.role });
      } catch (claimErr) {
        console.error(`[onApproval] Erro custom claims:`, claimErr);
      }

      // Notifica o professor via push
      const professorToken = await getTokenByUid(uid);
      if (professorToken) {
        await getMessaging().send({
          notification: {
            title: "Cadastro Aprovado!",
            body: "Seu cadastro foi aprovado. Bem-vindo(a) ao Diários Escolares!",
          },
          data: { type: "aprovacao", url: "/professor/index.html" },
          token: professorToken,
        });
      }

      // Envia e-mail
      const subject = "Bem-vindo(a) ao Diários Escolares!";
      const body = `Olá ${afterData.nome},\n\nSeu cadastro como professor foi aprovado! Você já pode acessar o sistema.\n\nAtenciosamente,\nEquipe Diários Escolares`;
      await sendEmail(afterData.email, subject, body);

      await getDatabase().ref(`/logs/aprovacoes/${uid}`).set({
        timestamp: Date.now(),
        action: "professor_aprovado",
        professorUid: uid,
        professorNome: afterData.nome,
        aprovadoPor: afterData.aprovadoPor || "sistema",
      });
    } catch (error) {
      console.error(`[onApproval] Erro:`, error);
      throw error;
    }
  }
  return null;
});

/**
 * Falta registrada → Notifica responsáveis do aluno
 */
exports.onFaltaRegistrada = onValueCreated(
  "/chamadas/{turmaId}/{data}/{chamadaId}",
  async (event) => {
    const faltaData = event.data.val();
    const { turmaId, data, chamadaId } = event.params;

    if (!faltaData || !faltaData.alunoUid) return null;

    try {
      console.log(
        `[onFaltaRegistrada] Falta: ${faltaData.alunoNome} - ${turmaId}`
      );

      const parentTokens = await getParentTokens(faltaData.alunoUid);

      if (parentTokens.length > 0) {
        const response = await sendMulticastNotification(
          parentTokens,
          "Registro de Falta",
          `${faltaData.alunoNome} teve falta registrada em ${faltaData.disciplina}.`,
          { type: "falta", alunoUid: faltaData.alunoUid, url: "/responsavel/index.html" }
        );
        console.log(
          `[onFaltaRegistrada] Notificou ${response.successCount} responsáveis.`
        );
      }

      await getDatabase().ref(`/logs/faltas/${chamadaId}`).set({
        timestamp: Date.now(),
        action: "falta_registrada",
        alunoUid: faltaData.alunoUid,
        alunoNome: faltaData.alunoNome,
        turmaId,
        data,
        disciplina: faltaData.disciplina,
      });
    } catch (error) {
      console.error(`[onFaltaRegistrada] Erro:`, error);
      throw error;
    }
    return null;
  }
);

/**
 * Bilhete enviado → Notifica destinatário
 */
exports.onBilheteEnviado = onValueCreated("/bilhetes/{id}", async (event) => {
  const bilheteData = event.data.val();
  const bilheteId = event.params.id;

  if (!bilheteData || !bilheteData.destinatarioUid) return null;

  try {
    console.log(`[onBilheteEnviado] Bilhete ${bilheteId} para ${bilheteData.destinatarioUid}`);

    const recipientToken = await getTokenByUid(bilheteData.destinatarioUid);

    if (recipientToken) {
      await getMessaging().send({
        notification: {
          title: `Novo Bilhete de ${bilheteData.remetenteNome}`,
          body: bilheteData.assunto || "Você recebeu um novo bilhete.",
        },
        data: {
          type: "bilhete",
          bilheteId,
          url: "/professor/bilhetes.html",
        },
        token: recipientToken,
      });
    }

    await getDatabase()
      .ref(`/bilhetes/${bilheteId}`)
      .update({ status: "entregue", entregueEm: Date.now() });

    await getDatabase().ref(`/logs/bilhetes/${bilheteId}`).set({
      timestamp: Date.now(),
      action: "bilhete_enviado",
      bilheteId,
      remetenteUid: bilheteData.remetenteUid,
      destinatarioUid: bilheteData.destinatarioUid,
    });
  } catch (error) {
    console.error(`[onBilheteEnviado] Erro:`, error);
    throw error;
  }
  return null;
});

/**
 * Nova nota lançada → Notifica responsáveis do aluno
 */
exports.onNotaLancada = onValueCreated(
  "/notas/{turmaId}/{disciplinaId}/{bimestre}/{avaliacaoId}",
  async (event) => {
    const notaData = event.data.val();
    const { turmaId, disciplinaId, bimestre, avaliacaoId } = event.params;

    if (!notaData || !notaData.alunoUid) return null;

    try {
      console.log(
        `[onNotaLancada] Nota para ${notaData.alunoNome} em ${notaData.disciplina}`
      );

      const parentTokens = await getParentTokens(notaData.alunoUid);

      if (parentTokens.length > 0) {
        const response = await sendMulticastNotification(
          parentTokens,
          "Nova Nota Lançada",
          `${notaData.alunoNome} recebeu nota ${notaData.valor} em ${notaData.disciplina}.`,
          { type: "nota", alunoUid: notaData.alunoUid, url: "/responsavel/boletim.html" }
        );
        console.log(
          `[onNotaLancada] Notificou ${response.successCount} responsáveis.`
        );
      }

      await getDatabase().ref(`/logs/notas/${avaliacaoId}`).set({
        timestamp: Date.now(),
        action: "nota_lancada",
        alunoUid: notaData.alunoUid,
        turmaId,
        disciplinaId,
        bimestre,
        valor: notaData.valor,
      });
    } catch (error) {
      console.error(`[onNotaLancada] Erro:`, error);
      throw error;
    }
    return null;
  }
);

/**
 * Comunicado criado → Notifica todos os destinatários por role
 */
exports.onComunicadoCriado = onValueCreated(
  "/comunicados/{id}",
  async (event) => {
    const comunicado = event.data.val();
    const comunicadoId = event.params.id;

    if (!comunicado) return null;

    try {
      console.log(`[onComunicadoCriado] Comunicado: ${comunicado.titulo}`);

      // Destinatários podem ser: "todos", "professores", "pais", "responsaveis"
      const destinatarios = comunicado.destinatarios || "todos";
      let tokens = [];

      if (destinatarios === "todos") {
        const allTokens = await Promise.all([
          getTokensByRole("professor"),
          getTokensByRole("pai"),
          getTokensByRole("responsavel"),
        ]);
        tokens = allTokens.flat();
      } else if (destinatarios === "professores") {
        tokens = await getTokensByRole("professor");
      } else if (
        destinatarios === "pais" ||
        destinatarios === "responsaveis"
      ) {
        const [paiTokens, respTokens] = await Promise.all([
          getTokensByRole("pai"),
          getTokensByRole("responsavel"),
        ]);
        tokens = [...paiTokens, ...respTokens];
      }

      // Remove duplicatas
      tokens = [...new Set(tokens)];

      if (tokens.length > 0) {
        const response = await sendMulticastNotification(
          tokens,
          comunicado.titulo || "Novo Comunicado",
          comunicado.resumo || comunicado.conteudo?.substring(0, 100) || "",
          { type: "comunicado", comunicadoId, url: "/diretor/comunicados.html" }
        );
        console.log(
          `[onComunicadoCriado] Notificou ${response.successCount} usuários.`
        );
      }

      await getDatabase().ref(`/logs/comunicados/${comunicadoId}`).set({
        timestamp: Date.now(),
        action: "comunicado_enviado",
        titulo: comunicado.titulo,
        destinatarios,
        totalNotificados: tokens.length,
      });
    } catch (error) {
      console.error(`[onComunicadoCriado] Erro:`, error);
      throw error;
    }
    return null;
  }
);

// ============================================================
// CLOUD FUNCTIONS - CALLABLE (chamadas pelo frontend)
// ============================================================

/**
 * Envia notificação push para um usuário específico
 * Chamável pelo frontend via Firebase SDK
 */
exports.sendPushNotification = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Autenticação necessária.");
  }

  const { targetUid, title, body, data } = request.data;

  if (!targetUid || !title || !body) {
    throw new HttpsError(
      "invalid-argument",
      "targetUid, title e body são obrigatórios."
    );
  }

  try {
    const token = await getTokenByUid(targetUid);
    if (!token) {
      return { success: false, message: "Destinatário sem token FCM." };
    }

    await getMessaging().send({
      notification: { title, body },
      data: data || {},
      token,
    });

    return { success: true, message: "Notificação enviada." };
  } catch (error) {
    console.error("[sendPushNotification] Erro:", error);
    throw new HttpsError("internal", error.message);
  }
});

/**
 * Envia notificação push para todos os usuários de um role
 */
exports.sendPushToRole = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Autenticação necessária.");
  }

  // Verificar se é diretor ou admin
  const callerSnap = await getDatabase()
    .ref(`/usuarios/${request.auth.uid}/role`)
    .once("value");
  const callerRole = callerSnap.val();

  if (callerRole !== "diretor" && callerRole !== "admin") {
    throw new HttpsError(
      "permission-denied",
      "Apenas diretores podem enviar notificações em massa."
    );
  }

  const { role, title, body, data } = request.data;

  if (!role || !title || !body) {
    throw new HttpsError(
      "invalid-argument",
      "role, title e body são obrigatórios."
    );
  }

  try {
    const tokens = await getTokensByRole(role);

    if (tokens.length === 0) {
      return { success: false, message: "Nenhum destinatário com token." };
    }

    const response = await sendMulticastNotification(tokens, title, body, data || {});

    return {
      success: true,
      sent: response.successCount,
      failed: response.failureCount,
    };
  } catch (error) {
    console.error("[sendPushToRole] Erro:", error);
    throw new HttpsError("internal", error.message);
  }
});
